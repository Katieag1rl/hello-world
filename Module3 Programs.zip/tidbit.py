DOWN_PAYMENT_RATE = 0.10
ANNUAL_INTEREST_RATE = 0.12
MONTHLY_PAYMENTS_RATE = 0.05
purchasePrice = float(input("Enter the purchase price: "))
month = 1
payment = purchasePrice * MONTHLY_PAYMENTS_RATE
startingBalance = purchasePrice
print("\n%s%19s%18s%19s%10s%17s" % ("Month", "Starting Balance", "Interest to pay", "Payment", "Ending Balance"))
while startingBalance > 0:
    interestToPay = startingBalance * ANNUAL_INTEREST_RATE / 12
    principalToPay = payment - interestToPay
    endingBalance = startingBalance - payment
    print("%2d%15.2f%16.2f%18.2f%18.2f%15.2f" % (month, startingBalance, interestToPay, principalToPay, payment, endingBalance))
    startingBalance = endingBalance
    month = month + 1
