height = float(input('Enter the height from which the ball is dropped: '))
bounci_index = float(input('Enter the bounciness index of the ball: '))
bounces = int(input('Enter the number of times the ball is allowed to continue bouncing: '))
distance = 0
while bounces > 0:
     height = height * bounci_index
     distance = distance + height
     distance = distance + height
     bounces = - 1
     print('Total distance traveled is %.3f' % distance)
