filename = input("Enter the file name: ")
f = open(filename, 'r')

def read_file(filename):
    try:
        with open(filename, 'r') as file:
            lines = file.readlines()
            return lines
    except FileNotFoundError:
        print(f"File '{filename}' not found.")
        return None


def main():
    filename = input("Enter the input file name: ")
    lines = read_file(filename)

    if lines is not None:
        while True:
            print(f"The file has {len(lines)} lines.")
            user_input = input("Enter a line number [0 to quit]: ")

            if user_input == '0':
                print("Quitting. Goodbye!")
                break

            try:
                line_number = int(user_input)
                if 1 <= line_number <= len(lines):
                    print(f"{line_number} : {lines[line_number - 1].strip()}")
                else:
                    print(f"Line number must be between 1 and {len(lines)} inclusive.")
            except ValueError:
                print("Invalid input. Please enter a valid line number (integer).")
                
