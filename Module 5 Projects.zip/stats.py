"""
File: stats.py
Prints the median, mean, and mode of a list in a file.
"""
fileName = input("Enter the file name: ")
f = open(fileName, 'r')

def median(list):
    if len(list) == 0:
        return 0
    sorted_list = sorted(list)
    mid_index = len(sorted_list) // 2
    if len(sorted_list) % 2 == 1:
        return sorted_list[mid_index]
    else:
        return (sorted_list[mis_index] + sorted_list[mid_index - 1]) / 2

    def mean(list):
        if len(list) == 0:
            return 0
        total = sum(list)
        return total / len(list)

    def mode(list):
        if len(list) == 0:
            return 0
        number_dict = {}
        for digit in list:
            if digit in number_dict:
                number_dict[digit] += 1
            else:
                number_dict[digit] = 1
        max_freq = max(number_dict.value())
        mode_list = [key for key, vlaue in number_dict.items() if value == max_freq]
        return mode_list

    def main():
        test_list = [45, 66, 22, 10, 15, 88, 15, 31, 90]
        print("List: ", test_list)
        print("Mode: ", mode(test_list))
        print("Median: ", median(test_list))
        print("Mean: ", mean(test_list))
