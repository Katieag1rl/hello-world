"""Program that prompt user for the names of two text files and copy the conent of first file to second file"""


def copy_file_content():
    input_fileName = input("Enter the name of source: ")
    output_fileName = input("Enter the name of the destination: ")
    
    try:
        with open(input_fileName, 'r') as source_file:
            fie_content = source_file.read()
           
        with open(output_fileName, 'w') as destination_file:
            destination_file.write(file_content)

        print(f"Content successfully copied from {input_fileName} to {output_fileName}")
        
    except FileNotFoundError:
        print("Error: One orr both of the specified files not found.")
        
