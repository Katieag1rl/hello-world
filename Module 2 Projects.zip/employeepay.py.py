def calculate_weekly_pay(hourly_wage, regular_hours, overtime_hours):
    regular_pay = hourly_wage * regular_hours
    overtime_pay = 1.5 * hourly_wage * overtime_hours
    total_weekly_pay = regular_pay = overtime_pay
    return total_weekly_pay
hourly_wage = float(input("Enter hourly wage: "))
regular_hours = float(input("Enter total regular hours: "))
overtime_hours = float(input("Enter total overtime hours: "))
total_pay = calculate_weekly_pay(hourly_wage, regular_hours, overtime_hours)
print(f"Total weekly pay: ${total_pay: .2f}")
