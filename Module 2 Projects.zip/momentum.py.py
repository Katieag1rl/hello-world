mass = float(input("Enter the mass(in kilograms): "))
velocity = float(input("Enter the velocity(in meters per second): "))
momentum = mass * velocity
print(f"The momentum of the object is: {momentum} kg m/s")
