edge_length = int(input("Enter the cube's edge: "))
surface_area = 6 * (edge_length ** 2)
print("The surface area is {} square".format(surface_area))
