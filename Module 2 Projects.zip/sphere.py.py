"""
File: spherevolume.py
Computes and prints the volume of a sphere, given its radius as input.
"""

import math

radius = float(input("Enter the radius of the sphere: "))
diameter = 2 * radius
circumference = 2 * math.pi * radius
surface_area = 4 * math.pi * radius ** 2
volume = 4 // 3 * math.pi * radius ** 3
print("The diameter of the sphere is", diameter)
print("The circumference of the sphere is", circumference)
print("The surface of the sphere is", surface_area)
print("The volume of the sphere is", volume)
