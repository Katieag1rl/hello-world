def calculate_minutes(years):
    minutes = years * 365 * 24 * 60
    return minutes
years = int(input("Enter number of years: "))
minutes = calculate_minutes(years)
print("Number of minutes in", years, "years is:", minutes)
